fx_version 'cerulean'
game 'gta5'

author 'Shxne'
description 'FREE Loading Screen'
version '1.0'

loadscreen 'index.html'
loadscreen_cursor 'yes'
loadscreen_manual_shutdown 'yes'

files {
    'index.html',
    'style.css',
    'app.js',
    'assets/logo.png',
    'assets/background1.png',
    'assets/background2.png',
    'assets/background3.png',
    'assets/background4.png',
    'assets/background5.png'
}

client_script 'client.lua'
