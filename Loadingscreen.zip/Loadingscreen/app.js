(function () {
    'use strict';

    const percentText = document.getElementById('percentText');
    const progressBarFill = document.getElementById('progressBarFill');
    const progressGlowHead = document.getElementById('progressGlowHead');
    const loadStageText = document.getElementById('loadStageText');
    const centerLogo = document.getElementById('centerLogo');

    let targetProgress = 0;
    let displayProgress = 0;
    let currentStage = 'INITIALIZING GAME CORE...';
    let isFiveM = false;
    let hasRealProgress = false;
    let totalDataFiles = 1;
    let loadedDataFiles = 0;

    function updateProgressLoop() {
        const diff = targetProgress - displayProgress;
        
        if (Math.abs(diff) > 0.05) {
            const speed = diff > 20 ? 0.2 : 0.08;
            displayProgress += diff * speed;
        } else {
            displayProgress = targetProgress;
        }

        const clamped = Math.min(100, Math.max(0, displayProgress));
        const clampedStr = clamped.toFixed(2) + '%';

        if (progressBarFill) {
            progressBarFill.style.width = clampedStr;
        }
        if (progressGlowHead) {
            progressGlowHead.style.left = clampedStr;
            progressGlowHead.style.opacity = clamped > 0.5 ? '1' : '0';
        }
        if (percentText) {
            percentText.textContent = Math.round(clamped);
        }

        requestAnimationFrame(updateProgressLoop);
    }
    requestAnimationFrame(updateProgressLoop);

    function SetProgress(value, stageName) {
        const val = Math.min(100, Math.max(0, value));
        if (val > targetProgress) {
            targetProgress = val;
        }
        if (stageName && stageName !== currentStage) {
            transitionStage(stageName);
        }
    }

    let stageTimeout = null;
    function transitionStage(newStage) {
        if (!loadStageText || newStage === currentStage) return;
        currentStage = newStage;

        loadStageText.classList.add('stage-fade-out');
        clearTimeout(stageTimeout);

        stageTimeout = setTimeout(() => {
            loadStageText.textContent = newStage.toUpperCase();
            loadStageText.classList.remove('stage-fade-out');
            loadStageText.classList.add('stage-fade-in');

            setTimeout(() => {
                loadStageText.classList.remove('stage-fade-in');
            }, 250);
        }, 180);
    }

    const FiveMHandlers = {
        loadProgress(data) {
            if (data && typeof data.loadFraction === 'number') {
                hasRealProgress = true;
                SetProgress(data.loadFraction * 100);
            }
        },
        startDataFileEntries(data) {
            if (data && data.count) {
                totalDataFiles = data.count;
                loadedDataFiles = 0;
            }
        },
        onDataFileEntry(data) {
            loadedDataFiles++;
            if (data && data.name) {
                const cleanName = data.name.replace(/^.*[\\\/]/, '');
                transitionStage('LOADING ASSETS: ' + cleanName);
            }
            if (!hasRealProgress && totalDataFiles > 0) {
                SetProgress((loadedDataFiles / totalDataFiles) * 65);
            }
        },
        performMapLoadFunction(data) {
            transitionStage('STREAMING MAP DATA...');
            if (!hasRealProgress && data && data.count) {
                SetProgress(65 + (data.idx / data.count) * 25);
            }
        },
        INIT_CORE() {
            transitionStage('INITIALIZING GAME CORE...');
            if (!hasRealProgress && targetProgress < 10) SetProgress(10);
        },
        INIT_BEFORE_MAP_LOADED() {
            transitionStage('LOADING GAME WORLD...');
            if (!hasRealProgress && targetProgress < 25) SetProgress(25);
        },
        MAP() {
            transitionStage('STREAMING ASSETS & TEXTURES...');
            if (!hasRealProgress && targetProgress < 65) SetProgress(65);
        },
        INIT_AFTER_MAP_LOADED() {
            transitionStage('SYNCHRONIZING SERVER STATE...');
            if (!hasRealProgress && targetProgress < 90) SetProgress(90);
        },
        INIT_SESSION() {
            transitionStage('JOINING GAME SESSION...');
            SetProgress(100);
        }
    };

    window.addEventListener('message', function (e) {
        if (!e.data) return;

        const eventName = e.data.eventName || e.data.type;
        if (!eventName) return;

        if (!isFiveM) {
            isFiveM = true;
            if (window.simInterval) clearInterval(window.simInterval);
        }

        const handler = FiveMHandlers[eventName];
        if (handler) {
            handler(e.data);
        }
    });

    let simulatedValue = 0;
    const stages = [
        { threshold: 18, name: 'INITIALIZING GAME CORE...' },
        { threshold: 42, name: 'LOADING GAME WORLD...' },
        { threshold: 68, name: 'STREAMING ASSETS & TEXTURES...' },
        { threshold: 90, name: 'SYNCHRONIZING SERVER SESSION...' },
        { threshold: 100, name: 'JOINING GAME SESSION...' }
    ];

    window.simInterval = setInterval(() => {
        if (isFiveM) return;

        if (simulatedValue < 100) {

            const step = Math.random() * 2.2 + 0.8;
            simulatedValue = Math.min(100, simulatedValue + step);

            const activeStage = stages.find(s => simulatedValue <= s.threshold) || stages[stages.length - 1];
            SetProgress(simulatedValue, activeStage.name);
        } else {
            clearInterval(window.simInterval);
        }
    }, 220);

    let mouseX = 0, mouseY = 0;
    let currentTiltX = 0, currentTiltY = 0;

    window.addEventListener('mousemove', (e) => {
        const cx = window.innerWidth / 2;
        const cy = window.innerHeight / 2;

        mouseX = ((e.clientX - cx) / cx) * 4.5;
        mouseY = -((e.clientY - cy) / cy) * 4.5;
    });

    window.addEventListener('mouseleave', () => {
        mouseX = 0;
        mouseY = 0;
    });

    const bgSlider = document.getElementById('bgSlider');

    function tiltLoop() {
        currentTiltX += (mouseX - currentTiltX) * 0.08;
        currentTiltY += (mouseY - currentTiltY) * 0.08;

        if (centerLogo) {
            centerLogo.style.transform = `rotateY(${currentTiltX.toFixed(2)}deg) rotateX(${currentTiltY.toFixed(2)}deg)`;
        }
        if (bgSlider) {
            bgSlider.style.transform = `translate(${(-currentTiltX * 1.8).toFixed(2)}px, ${(-currentTiltY * 1.8).toFixed(2)}px)`;
        }
        requestAnimationFrame(tiltLoop);
    }
    requestAnimationFrame(tiltLoop);

    const bgSlides = document.querySelectorAll('.bg-slide');
    const indicatorTracks = document.querySelectorAll('.slide-indicators .indicator-track');

    function syncIndicators(activeIndex) {
        indicatorTracks.forEach((track, idx) => {
            track.classList.remove('active', 'completed');
            const bar = track.querySelector('.indicator-bar');
            if (bar) {
                bar.style.animation = 'none';
                void bar.offsetWidth;
                bar.style.animation = '';
            }

            if (idx === activeIndex) {
                track.classList.add('active');
            } else if (idx < activeIndex) {
                track.classList.add('completed');
            }
        });
    }

    if (bgSlides.length > 1) {

        const bgImages = [
            'assets/background1.png',
            'assets/background2.png',
            'assets/background3.png',
            'assets/background4.png',
            'assets/background5.png'
        ];
        bgImages.forEach((src) => {
            const img = new Image();
            img.src = src;
        });

        let currentSlideIndex = 0;
        const slideIntervalTime = 6000;
        const normalCrossfade = 1500;
        const fastCrossfade = 650;
        let slideTimer = null;
        let cleanupTimer = null;

        function playClickSound() {
            try {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (!AudioCtx) return;
                if (!window.uiAudioCtx) window.uiAudioCtx = new AudioCtx();
                const ctx = window.uiAudioCtx;
                if (ctx.state === 'suspended') ctx.resume();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(880, ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(360, ctx.currentTime + 0.04);
                gain.gain.setValueAtTime(0.045, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.04);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start();
                osc.stop(ctx.currentTime + 0.04);
            } catch (e) {

            }
        }

        function goToSlide(targetIndex, isManual = false) {
            if (targetIndex === currentSlideIndex || targetIndex < 0 || targetIndex >= bgSlides.length) {
                return;
            }

            if (cleanupTimer) {
                clearTimeout(cleanupTimer);
                cleanupTimer = null;
            }

            const prevSlide = bgSlides[currentSlideIndex];
            currentSlideIndex = targetIndex;
            const nextSlide = bgSlides[currentSlideIndex];
            const bgContainer = document.getElementById('bgSlider');

            bgSlides.forEach((slide, idx) => {
                if (idx !== currentSlideIndex && slide !== prevSlide) {
                    slide.classList.remove('active', 'outgoing');
                }
            });

            if (isManual && bgContainer) {
                bgContainer.classList.add('fast-transition');
            }

            prevSlide.classList.remove('active');
            prevSlide.classList.add('outgoing');

            nextSlide.classList.remove('outgoing');
            void nextSlide.offsetWidth;
            nextSlide.classList.add('active');

            syncIndicators(currentSlideIndex);

            const duration = isManual ? fastCrossfade : normalCrossfade;
            cleanupTimer = setTimeout(() => {
                prevSlide.classList.remove('outgoing');
                if (isManual && bgContainer) {
                    bgContainer.classList.remove('fast-transition');
                }
                cleanupTimer = null;
            }, duration + 50);
        }

        function startSlideTimer() {
            if (slideTimer) clearInterval(slideTimer);
            slideTimer = setInterval(() => {
                const nextIndex = (currentSlideIndex + 1) % bgSlides.length;
                goToSlide(nextIndex, false);
            }, slideIntervalTime);
        }

        indicatorTracks.forEach((track, idx) => {
            const handleSelect = (e) => {
                e.preventDefault();
                if (idx === currentSlideIndex) return;
                playClickSound();
                goToSlide(idx, true);
                startSlideTimer();
            };

            track.addEventListener('click', handleSelect);
            track.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    handleSelect(e);
                }
            });
        });

        syncIndicators(0);
        startSlideTimer();

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                syncIndicators(currentSlideIndex);
            }
        });
    }
})();
