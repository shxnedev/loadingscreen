local hasShutdown = false

local function DoShutdown()
    if not hasShutdown then
        hasShutdown = true
        SendNUIMessage({
            eventName = 'INIT_SESSION'
        })
        Citizen.Wait(600)
        ShutdownLoadingScreenNui()
    end
end

AddEventHandler('playerSpawned', function()
    DoShutdown()
end)

RegisterNetEvent('esx:playerLoaded', function()
    DoShutdown()
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    DoShutdown()
end)

exports('ShutdownLoadingScreen', DoShutdown)

RegisterCommand('stoploadscreen', function()
    DoShutdown()
end, false)
